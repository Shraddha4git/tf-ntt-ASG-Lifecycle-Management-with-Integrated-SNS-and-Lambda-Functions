import boto3

def lambda_handler(event, context):
    # Your script logic here
    print("Running custom termination script")

    # Complete the lifecycle action
    client = boto3.client('autoscaling')
    response = client.complete_lifecycle_action(
        LifecycleHookName='TerminateHook',
        AutoScalingGroupName='tf-low-cost-asg',
        LifecycleActionResult='CONTINUE',
        InstanceId=event['detail']['EC2InstanceId']
    )
    return response
